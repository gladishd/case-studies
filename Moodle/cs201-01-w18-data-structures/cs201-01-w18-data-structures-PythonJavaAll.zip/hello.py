'''
   hello.py
   Jeff Ondich, 2013-01-04
   Anna Rafferty, 2016-08-24 (conversion to python3)

   Intended as the Python half of parallel examples in Python and
   Java. See Hello.java.
'''

print('Hello world!')