/**
 * Hello.java
 * Jeff Ondich, Carleton College, 2014-01-01
 *
 * Hello world, Java style.
 *
 * This is the Java half of a pair of parallel examples in Python and Java.
 * See hello.py.
 */
public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}